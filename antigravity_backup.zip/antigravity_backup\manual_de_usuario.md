# 🎈 Manual del Sistema IDD: ¡Explicado como a un niño de 5 años! 🚀

¡Hola, súper explorador/a! 👋 Bienvenido a la máquina mágica de proyectos de **IDD**. 

Imagínate que esta aplicación es como una **caja de juguetes gigante** donde organizamos experimentos, proyectos y tareas para hacer productos super deliciosos y nutritivos. 

¡Aquí te enseñamos cómo usarla en 4 pasos mágicos! 🪄✨

---

## 🚦 Paso 1: Los Semáforos Mágicos de Colores (¡Para no chocar!)

En la pantalla verás lucecitas de colores al lado de cada proyecto. ¡Son como los semáforos de la calle! 🚗🚦

* 🟢 **VERDE (Luz Verde)**: ¡Todo va genial! El proyecto está listo a tiempo o tenemos muchos días para terminarlo sin prisa. 🥳
* 🟡 **AMARILLO (Luz Amarilla)**: ¡Cuidado, apúrate un poquito! Faltan menos de 3 días para entregar la tarea. ⏳
* 🔴 **ROJO (Luz Roja)**: ¡Ocurrió un retraso! La fecha de entrega ya pasó y hay que revisar qué sucedió. 🛑

---

## 🧸 Paso 2: Los 6 Cuartos de Juguetes (Los 6 Módulos Gerenciales)

Arriba en la pantalla hay botones de colores. Cada uno te lleva a un "cuarto" diferente:

1. 🚀 **Cuarto 1: IDD / Proyectos**: Aquí están todos los proyectos grandes (como hacer una súper bebida o un chocolate especial). ¡Si tocas cualquier proyecto, se abre una tarjeta con todos sus secretos!
2. 🧪 **Cuarto 2: Aplicaciones**: Son las pequeñas pruebas que hacemos para los clientes.
3. 🎧 **Cuarto 3: Asistencia Técnica**: Cuando los amigos de Comercial nos piden ayuda para explicarle a un cliente cómo usar un ingrediente.
4. ⏱️ **Cuarto 4: Capacidad (Reloj Mágico)**: Aquí anotamos hora por hora lo que hace cada científico del equipo durante el día.
5. 📚 **Cuarto 5: Capacitaciones**: El salón de clases donde aprendemos cosas nuevas o le enseñamos a otros.
6. 📊 **Cuarto 6: Homologaciones y Presupuesto**: Para revisar las materias primas y asegurarnos de no gastar más monedas de las que tenemos.
7. ⚙️ **Cuarto 7: Catálogos**: ¡Para invitar a nuevos amiguitos al equipo o agregar nuevas líneas de productos!

---

## 🪄 Paso 3: ¿Cómo Crear, Editar o Borrar Cosas? (El Juego CRUD)

Es súper sencillo, solo buscas los botones mágicos:

* ➕ **Botón Azul (`+ Crear`)**: Es para agregar un nuevo juguete o proyecto a la caja.
* ✏️ **Botón Celeste (`Editar`)**: Si te equivocaste en un nombre o quieres cambiar un dato, tócalo y edítalo.
* 📅 **Botón Amarillo (`Auditar Fecha`)**: Si necesitas más tiempo para entregar un proyecto, este botón te permite cambiar la fecha pero te pedirá escribir una notita explicando por qué.
* 🗑️ **Botón Rojo (`Eliminar`)**: Si un borrador ya no sirve, lo tiramos a la papelera.
* 🔍 **Botón Azul (`Ficha`)**: ¡Al tocar la palabra del proyecto o el botón Ficha, se abre una súper tarjeta gigante con todo lo que tiene ese proyecto! Y arriba a la derecha tiene una **❌ Equis roja gigante** para cerrarla cuando termines de mirar.

---

## 📄 Paso 4: Sacar una Foto e Imprimir (Exportar PDF y Excel)

¿Quieres mostrarle tu trabajo al jefe o a tu equipo? 

En la parte de arriba de cada cuarto verás dos botones mágicos:
* 📊 **`Exportar Excel`**: Te descarga una tabla verde de cálculo con todos los números ordenados.
* 📄 **`Exportar PDF`**: Te crea una hoja muy bonita para imprimir o enviar por correo.

---

## 🎁 ¡Resumen Rápido en 3 Palabras!

1. **Mira los colores** 🟢🟡🔴 (Verde = bien, Rojo = atención).
2. **Toca cualquier proyecto** 🔍 para ver su tarjeta mágica (y usa la **❌** para cerrarla).
3. **Usa los botones** 📊 Excel y 📄 PDF para guardar tus reportes.

¡Y listo! Ya eres un experto/a manejando el Sistema Integrado IDD. 🌟
