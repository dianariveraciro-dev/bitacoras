# Implementation Plan - Sistema Integrado de Gestión de Proyectos, Bitácoras, Capacidad e Indicadores IDD (PDR - V2)

Este plan integra **el 100% de la especificación técnica contenida en el documento PDR - V2** (7 páginas), cubriendo roles, clasificaciones, reglas de auditoría, causales de cierre, matriz de capacidad hora a hora, los 6 módulos gerenciales, la estructura SQL relacional y los principios UI/UX.

---

## Mapeo Completo del PDR V2 en el Sistema

### 1. Perfiles de Usuario y Roles (Sección 1.1)
- **Director IDD**: Dashboards gerenciales, aprobación de reasignaciones y presupuestos, reportes institucionales.
- **Líder IDD**: Asignación de proyectos, seguimiento en comité semanal, evaluación de capacidad y entregables.
- **Líder Técnica**: Validación técnica, homologación de materias primas, pruebas piloto y escalamiento.
- **Asistente IDD**: Registro diario de time-tracking, ejecución de ensayos de laboratorio, bitácoras secundarias.
- **Proceso Comercial / Asesor**: Solicitudes iniciales de aplicación/asistencia y seguimiento comercial para cierre.

### 2. Matriz de Entidades, Tipologías y Centros de Costo (Sección 2.1)
- **Categoría de Proyecto**: `Desarrollo`, `Investigación`, `Moonshot`.
- **Marca / Línea**: `Alimento Nutricional`, `Be-Balance`, `Food Service`, `Industrial`, `Marca Blanca`, `Nutricure`, `Zeto`.
- **Modelo de Negocio**: `Alsec Revolution (Innovación Disruptiva)`, `Aplicación / Soporte Técnico`, `Comercialización`, `Crisol-Ingrediente a la Medida`, `Productos B2C - Líquido`, `Productos B2C - Polvo`, `Soluciones B2B_Internacional-Líquido`, `Soluciones B2B_Internacional-Polvo`, `Soluciones B2B_Nacional-Líquido`, `Soluciones B2B_Nacional-Polvo`.
- **Tecnología**: `Secado por Aspersión y Microencapsulación`, `Separación por Membranas`, `Tratamiento Térmico UHT`, `Procesamiento Retortable (Esterilización)`, `Mezclado (Dry Blend / Blending)`, `Biotecnología`, `Hidrólisis Enzimática`, `Extracción / Concentración`, `Multitecnología / Combinado`.
- **Centros de Costo (CC)**:
  - `551` (Aplicaciones)
  - `561` (Desarrollos)
  - `571` (Investigación)
  - `584` (Proyecto Orquídeas)
  - `591` (Nutrición Avanzada)
  - `144` (Homologación)

### 3. Trazabilidad Temporal de Fechas y Auditoría (Sección 3.1)
Captura obligatoria de las 6 fechas estándar por bitácora:
1. `Fecha de Solicitud / Ingreso`
2. `Fecha Real de Inicio`
3. `Fecha de Reasignación`
4. `Fecha Compromiso de Entrega`
5. `Fecha Real de Entrega`
6. `Fecha Cierre del Proyecto`

> [!IMPORTANT]
> **Regla de Auditoría del PDR**: La *Fecha Compromiso de Entrega* NUNCA se borra ni sobreescribe. Si el proyecto se pausa, reformula o reasigna, el sistema exige una nota/observación obligatoria justificando el cambio de estado y conserva el historial auditable.

### 4. Funnel de 10 Etapas del Proyecto (Sección 3.2)
1. `Por Definir / Briefing`
2. `En Desarrollo (Laboratorio)`
3. `En Documentación`
4. `En Evaluación / Enviado a Cliente`
5. `Re-formulación`
6. `Prueba Piloto / Escalamiento`
7. `Stand By / En Espera`
8. `Estudio de Estabilidad / Vida Útil`
9. `Éxito / Aprobado`
10. `Cancelado / Descartado`

### 5. Cierre Comercial y 12 Causales de Cierre (Sección 3.3)
- `Ganado / Compran (Facturando)`
- `Aprobado No Compran`
- `Éxito Reformulación`
- `Rechazado por Sensorial`
- `Rechazado por Funcionalidad`
- `Rechazado por Precio / Costo Objetivo`
- `Rechazado por Vida Útil / Estabilidad`
- `Cancelado por Cliente`
- `Cancelado por Asesor / Comercial`
- `Fuera de Tiempo (Entregado Tarde)`
- `Rechazado por Regulación / Legales`
- `Rechazado por Capacidad Industrial / No Viable`
- **Módulo de Impacto Comercial**: Seguimiento a ventas reales anuales por proyecto facturado ($ ROI).

### 6. Módulo de Capacidad Hora a Hora (Time-Tracking Diario) (Sección 4)
Registro de jornada laboral estructurado en las 5 categorías:
1. `ESTRATEGIA`
2. `SOPORTE DE VALOR` (incluye Asistencias Técnicas a Comercial)
3. `CARGA OPERATIVA` (incluye Ensayos, Pilotos, Documentación)
4. `BIENESTAR Y CULTURA`
5. `TIEMPO NO LABORAL`
- **Salidas Automáticas**: Consolidación automática de horas de Capacitación Técnica (recibidas/dictadas por investigador) y horas dedicadas a Asistencias Técnicas Comercial.

### 7. Motor de Fórmulas de Indicadores KPIs (Sección 5)
- **Cumplimiento OTD (%)**: $$\text{OTD (\%)} = \left(\frac{\text{Solicitudes/Proyectos Entregados a Tiempo}}{\text{Total Solicitudes Evaluadas}}\right) \times 100$$
- **Desviación de Tiempos (Días y %)**: 
  $$\text{Desviación (Días)} = \text{Días Reales} - \text{Días Estimados (Compromiso)}$$
  $$\%\text{ Desviación} = \left[\frac{\text{Días Reales} - \text{Días Estimados}}{\text{Días Estimados}}\right] \times 100$$
- **% Incremento de Eficiencia**: $$\%\text{ Incremento Eficiencia} = \left[\frac{\text{Valor Nuevo} - \text{Valor Actual}}{\text{Valor Actual}}\right] \times 100$$
- **Lead Time Total**: $$\text{Lead Time} = \text{Fecha Cierre} - \text{Fecha Solicitud/Ingreso}$$
- **Tiempo Activo en Desarrollo**: $$\text{Tiempo Activo} = \text{Fecha Real Entrega} - \text{Fecha Real Inicio}$$

### 8. Los 6 Módulos Gerenciales (Sección 6)
1. **Módulo IDD / Proyectos**: Funnel, distribución por categoría/marca/tecnología, causales de cierre, ventas anuales, OTD Proyectos, % Desviación y Lead Time.
2. **Módulo Aplicaciones**: Solicitudes activas, evaluación cliente, OTD Aplicaciones.
3. **Módulo Asistencia Técnica**: Requerimientos del área comercial, horas invertidas y tiempo promedio de respuesta.
4. **Módulo Capacidad del Proceso**: Ocupación hora a hora por rol, % de capacidad utilizada vs disponible por perfil y balanceo de carga en las 5 categorías.
5. **Módulo Capacitaciones**: Consolidado de horas acumuladas de formación técnica dictada/recibida en total y por investigador/asistente.
6. **Módulo Homologaciones, Eficiencias y Presupuesto**: Homologación de materias primas, proyectos de optimización (% incremento eficiencia) y ejecución presupuestal ($ Real vs Asignado) por los 6 Centros de Costo (`551`, `561`, `571`, `584`, `591`, `144`).

### 9. Principios de Interfaz UI/UX (Sección 7)
- **KPI Cards**: Tarjetas superiores dinámicas con porcentaje de cumplimiento (%) y proyectos activos.
- **Semáforos Visuales**:
  - 🟢 **VERDE**: Entregado a tiempo o $\ge 3$ días restantes dentro del margen.
  - 🟡 **AMARILLO**: Próximo a vencer ($< 3$ días para la fecha compromiso).
  - 🔴 **ROJO**: Solicitud retrasada / Fecha compromiso vencida.
- **Filtros Rápidos e Interactivos**: Por `Investigador`, `Línea/Marca`, `Centro de Costos` o `Rango de Fechas`.
- **Navegación Directa**: Menú visual con acceso directo a los 6 Módulos Gerenciales sin menús ocultos.

---

## Archivos a Crear / Modificar

### Componentes y Estructura
1. **[schema.sql](file:///d:/Mis%20documentos/Descargas/Antigravity/Bitacoras-capacisdad-%20indicadoress/schema.sql)**: Modelo relacional SQL completo con tablas `proyectos`, `aplicaciones`, `asistencias_tecnicas`, `capacidad_time_tracking`, `capacitaciones`, `homologaciones`, `eficiencias`, `presupuesto_ejecucion`, `auditoria_fechas` y claves foráneas.
2. **[styles.css](file:///d:/Mis%20documentos/Descargas/Antigravity/Bitacoras-capacisdad-%20indicadoress/styles.css)**: Estilos gerenciales modernos, tema oscuro/claro, semáforos interactivos, badges del funnel, matriz de capacidad y KPI Cards.
3. **[index.html](file:///d:/Mis%20documentos/Descargas/Antigravity/Bitacoras-capacisdad-%20indicadoress/index.html)**: Estructura SPA con filtros globales, KPI Cards, navegación por 6 módulos + pestaña de Esquema DB, modales de auditoría y formularios hora a hora.
4. **[db.js](file:///d:/Mis%20documentos/Descargas/Antigravity/Bitacoras-capacisdad-%20indicadoress/db.js)**: Base de datos reactiva en cliente con datos seed representativos de IDD, validaciones de auditoría en fecha compromiso y persistencia en LocalStorage.
5. **[kpis.js](file:///d:/Mis%20documentos/Descargas/Antigravity/Bitacoras-capacisdad-%20indicadoress/kpis.js)**: Motor algebraico de KPIs (OTD, Desviación, Eficiencia, Lead Time, Capacidad por rol/categorías).
6. **[app.js](file:///d:/Mis%20documentos/Descargas/Antigravity/Bitacoras-capacisdad-%20indicadoress/app.js)**: Renderizado dinámico de los 6 módulos, modales de registro/auditoría, time-tracking interactivo y exportador de base de datos SQL.

---

## Plan de Verificación

### Pruebas de Software y UI
- Comprobar que los semáforos cambien dinámicamente según la diferencia entre la fecha actual/real y la `Fecha Compromiso`.
- Verificar que al intentar modificar una `Fecha Compromiso`, el sistema solicite obligatoriamente la nota de justificación de auditoría.
- Probar el registro de horas en la matriz de Capacidad del Proceso y verificar que se refleje inmediatamente en los consolidados de Capacitación y Asistencia Técnica.
- Validar el cálculo exacto de OTD %, Desviación %, % Incremento de Eficiencia y Ejecución Presupuestal.
